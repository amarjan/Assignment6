
public class User{
	/**
	 * @author amarjan tursun
	 */
			 String id;
     private String username;
     private String password;
    private double money;
	public User(String username,String password,double money) {
		// TODO Auto-generated constructor stub
		this.username =username;
		this.password=password;
		this.money=money;
	}
	public String getId(){
		
		return this.id;
	} 
	public void setId(String id){
		this.id=id;
	}
	
	/**
	 * 
	 * @return username;
	 */
	public String getUsername(){
		
		return this.username;
	}
	
	/**
	 * 
	 * @param username
	 */
	public void setUsername(String username){
		
		this.username= username;
	}
	
	/**
	 * 
	 * @return password
	 */
	public String getPassword(){
		
		return this.password;
	}
	
	/**
	 * 
	 * @param password
	 */
   public void setPassword(String password){
	  this.password=password;
  }
   
   /**
    * 
    * @return money
    */
 
   public Double getMoney(){
	  
	  return this.money;
  }
  
  /**
   * 
   * @param money
   */
  public void setMoney(Double money){
	  
	  this.money=money;
  }
  
}