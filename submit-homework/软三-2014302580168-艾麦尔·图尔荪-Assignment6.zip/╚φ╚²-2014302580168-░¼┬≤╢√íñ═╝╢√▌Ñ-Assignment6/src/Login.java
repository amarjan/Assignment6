import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JPanel {
private JButton loginBtn;
private JButton registerBtn;
private JTextField username;
private JPasswordField password;
	/**
	 * Create the panel.
	 */
	public Login() {
		setSize(400,400);
		loginBtn.setBounds(100, 300, 15, 20);
		registerBtn.setBounds(200, 300, 15, 20);
		username.setBounds(100,100,15 ,20);
		password.setBounds(100, 200, 15, 20);
		getRootPane().add(username);
		getRootPane().add(loginBtn);
		getRootPane().add(password);
		getRootPane().add(registerBtn);
	}

}
