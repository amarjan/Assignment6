import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class Database {
     static Double money;
     
	public Database() {
		// TODO Auto-generated constructor stub
	}
	private static Connection getConnection() {
	    String driver = "com.mysql.jdbc.Driver";
	    String url = "jdbc:mysql://localhost:3306/Pet_store_schema?";
	    String username = "root";
	    String password = "123456";
	    Connection conn = null;
	    try {
	        Class.forName(driver); //classLoader,���ض�Ӧ����
	        conn = (Connection) DriverManager.getConnection(url, username, password);
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return conn;
	}
	
	/**
	 * 
	 * @param new user register
	 */
	public static void User_register(User newuser) { 
	    Connection conn = getConnection();
	   // int i = 0;
	    String sql = "insert into Users (username,password,money) values(?,?,?)";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        pstmt.setString(1, newuser.getUsername());
	        pstmt.setString(2, newuser.getPassword());
	        pstmt.setDouble(3,newuser.getMoney());
	   //     i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
}
/**
 * 
 * @param username
 * @return
 */
	public static Boolean Checkusername(String username){
	String Sql="select * from User where username="+username+"";
	ResultSet resultset=selectFromDtabase(Sql);
	if(null !=resultset)
		return true;
	else return false;
     }	
	
	/**
	 * 
	 * @param username
	 * @param password
	 * @return whether the passworrd is true ;
	 */
	
	public static Boolean Login(String username,String password)
	{
			String Sql="select * from User where username="+username+"";
			ResultSet resultset=selectFromDtabase(Sql);
		try {
			String Databasepassword=resultset.getString(2);
			//money=resultset.getDouble(3);
			if(Databasepassword.equals(password))
				money=resultset.getDouble(3);
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		}
		
	
	
	/**
	 * 
	 * @param Sql_select_formal
	 * @return afterselect information
	 */
	public static ResultSet selectFromDtabase(String Sql_select_formal){
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet resultset=null;
		try {
			conn=getConnection();
			pstmt=(PreparedStatement)conn.prepareStatement(Sql_select_formal);
			 resultset=pstmt.executeQuery();
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		if(resultset== null)
	 		return null;
		else return resultset;
	}
	
	/**
	 * 
	 * @return petlist;
	 */
	public List<Map<String,String>> getPetlist(){
		List<Map<String,String>> petlist=new ArrayList<Map<String,String>>();
		String sql="select * from petlist";
		ResultSet resultset=selectFromDtabase(sql);
		
		try {
			while(resultset.next()){
			
				Map<String,String> pet=new HashMap<String,String>();
				pet.put("id",resultset.getString(0));
				pet.put("name", resultset.getString(1));
				pet.put("eat",resultset.getString(2));
				pet.put("drink",resultset.getString(3));
				pet.put("live ",resultset.getString(4));
				pet.put("hobby ",resultset.getString(5));
				petlist.add(pet);
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		return petlist;
	}
}

